Office HQ for Mac — install from your iPhone/iPad
=================================================

1. AirDrop this ZIP or its download URL to your Mac.
2. On the Mac, download the ZIP and double-click to extract it.
3. Open Office HQ.app. If macOS blocks the unsigned app, inspect its
   origin and use Finder > Control-click > Open, or System Settings
   > Privacy & Security > Open Anyway only if you trust this file.
4. Approve the setup dialog. The launcher fetches your GitHub app,
   privately installs Node.js when necessary, and starts the local
   Office HQ website at http://127.0.0.1:3000/#/thread.

On each launch, choose Update Office HQ to install the newest GitHub code.
Application code is backed up before updating; personal workspace data
is preserved, and no external accounts are authorized automatically.

This is a Mac launcher, not a signed offline application.
On setup it fetches and installs the full independent Ollama runtime and
llama3.2:3b model from the official vendor. These are several GB and run
locally on your Mac. First installation requires internet and macOS 14+.
The Mac sync engine connects to your existing private Office HQ cloud
account only AFTER you sign in under Company Messages. Sign in on your
iPhone/iPad with the same account to begin automatic assignment sync.
Authorize each Mac AI specialist separately to prepare draft-only work.
Optional browser setup installs Chromium and qwen2.5vl:7b with separate consent.
Use Agent website access to select sites, named accounts, and individual or all
agents. Sign in directly on each website on the Mac. Permission cards gate
access, and account changes stop for separate one-click approval. Money and
account-security actions are not delegated.

Coding tasks supports a separately approved repository snapshot, selected source
files and exact Node/npm checks. The local tool-capable Ollama model must be
configured on the Mac. Coding tasks use local Ollama only; no cloud provider
key is required. No publishing happens automatically.

Your company records are stored separately on each device unless
you configure authenticated sync.
