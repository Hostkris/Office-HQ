Office HQ for Mac — install from your iPhone/iPad
=================================================

1. AirDrop this ZIP or its download URL to your Mac.
2. On the Mac, download the ZIP and double-click to extract it.
3. Open Office HQ.app. If macOS blocks the unsigned app, inspect its
   origin and use Finder > Control-click > Open, or System Settings
   > Privacy & Security > Open Anyway only if you trust this file.
4. Approve the setup dialog. The launcher fetches your GitHub app,
   privately installs Node.js when necessary, and starts the local
   Office HQ website at http://127.0.0.1:3000/#/thread.

Existing ~/Office-HQ files are NEVER replaced automatically.

This is a Mac web-server launcher, not a signed offline application.
It does not install or enable optional third-party AI runtimes,
external account sessions, financial access or Mac-iOS sync.
If you already have the independent local AI engine, it is preserved.
First installation requires internet; macOS 14+ is required.
Your company records are stored separately on each device unless
you configure authenticated sync.
